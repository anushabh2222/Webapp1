package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection ="teacher")
public class Teacher {
	
public static final String SEQUENCE_NAME = "teacher_sequence"; 
@Id

private Long id;
private String name;
private String specification;
private String createdate;
public Long getId() {
	return id;
}
public void setId(Long id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getSpecification() {
	return specification;
}
public void setSpecification(String specification) {
	this.specification = specification;
}
public String getCreatedate() {
	return createdate;
}
public void setCreatedate(String createdate) {
	this.createdate = createdate;
}
@Override
public String toString() {
	return "Teacher [id=" + id + ", name=" + name + ", specification=" + specification + ", createdate=" + createdate
			+ "]";
}

	

}
