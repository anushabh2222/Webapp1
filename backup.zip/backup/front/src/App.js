import React from 'react';

import './App.css';
import  CreateStudentComponent from './Components/CreateStudentComponent';
import  Home from './Components/Home';
import {BrowserRouter as Router, Route} from 'react-router-dom'
import HeaderComponent from './Components/HeaderComponent';
import FooterComponent from './Components/FooterComponent';
import NavBar from './NavBar';

// import  Teacher from './Teacher';



function App() {
  return (
    <div> 
      <Router>
              <HeaderComponent />
                <div className="container">
                   
      <NavBar/>
      <Route exact path="/" component={Home}/> 
      <Route  exact path="/student" component={CreateStudentComponent}/> 
      {/* <Route  exact path="/teacher" component={Teacher}/>  */}

    </div>
    <FooterComponent />
    </Router>
    </div>
  );
}

export default App;
