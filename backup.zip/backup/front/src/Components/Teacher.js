import { React, Component } from 'react';
import './App.css';

class Teacher extends Component {
  constructor(){
    super();
    this.state = {
      // title : " web Application",
      act : 0,
      idx : '',
      datas : []
    }
  }

  componentDidMount(){
    this.refs.name.focus();
  }

  handleSubmit=(e)=>{
    e.preventDefault();
    let datas = this.state.datas;
    let name = this.refs.name.value;
    let specification = this.refs.specification.value;
    let createdate = this.refs.createdate.value;

    if(this.state.act === 0)
    {
      let data = {
        "name" : name,
        "specification" : specification,
        
        "createdate":createdate
      }
      datas.push(data);
    }
    else
    {
        let index = this.state.idx;
        datas[index].name = name;
        datas[index].specification = specification;    
        datas[index].createdate = createdate;         
    }
    
    
    this.setState({
      datas : datas,
      act : 0
    })
    this.refs.myForm.reset();
    this.refs.name.focus();
  }

  handleDelete = (index) =>{
    let datas = this.state.datas;
    datas.splice(index,1);
    this.setState({
      datas:datas
    })
    this.refs.name.focus();
  }

  handleEdit = (index) => {
    let data = this.state.datas[index];
    this.refs.name.value = data.name;
    this.refs.specification.value = data.specification;
    this.refs.createdate.value = data.createdate;
    

    this.setState({
      act: 1,
      idx : index
    })
    
  }
  
  render() { 
    let datas = this.state.datas;
    return ( 
      <div className="App">
      
        <form ref="myForm" className="myForm">
        <h1>{this.state.title}</h1>
        <h2>Teacher registration</h2>
          <label>Name</label>
          <input type="text" ref="name" placeholder="Enter name" className="formField"/>
          <label>Specification</label>
          <input type="text" ref="specification" placeholder="Enter specification"  className="formField"/>
          <label>Created date</label>
          <input type="text" ref="createdate" placeholder="Enter created date" className="formField"/>
          
          <button onClick={e => this.handleSubmit(e)} className="myButton"> Save</button>
        </form>
        <pre className="listView">
          {datas.map((data,index)=>
            <li key={index}>  
            {index+1}, {data.name} ,{data.specification},{data.createdate}  
            <button onClick={e => this.handleDelete(index)} className="myListButton">Delete</button>
            <button onClick={e => this.handleEdit (index)} className="myListButton">Edit</button>
            </li>
            )
          }
        </pre>
      </div>
     );
  }
}
 
export default Teacher;