package com.example.demo.controller;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Service.StudentService;
import com.example.demo.model.Student;
import com.example.demo.repositories.StudentRepository;



@RestController
@RequestMapping("/api")
public class StudentController {

	@Autowired
	StudentRepository studentRepository;
	
	@Autowired
	StudentService studentService;
	
	
	
	@PostMapping("/create")
	public Student create(@RequestBody Student newStudentObject) {
		newStudentObject.setId(studentService.generateSequence(Student.SEQUENCE_NAME));
		return studentRepository.save(newStudentObject);
	}
	
	@GetMapping("/read")
	public List<Student> read(){
		return studentRepository.findAll();
	}
	
	@GetMapping("/read/{id}")
	public Student read(@PathVariable Long id) {
		Optional<Student> stuObj = studentRepository.findById(id);
		if(stuObj.isPresent()) {
			return stuObj.get();
		}else {
			throw new RuntimeException("student not found with id "+id);
		}
	}
	
	@PutMapping("/update")
	public Student update(@RequestBody Student studentObject) {
		return studentRepository.save(studentObject);
	}
	
	@DeleteMapping("/delete/{id}")
	public String delete(@PathVariable Long id) {
		Optional<Student> studentObj = studentRepository.findById(id);
		if(studentObj.isPresent()) {
			studentRepository.delete(studentObj.get());
			return "student deleted with id "+id;
		}else {
			throw new RuntimeException("student not found for id "+id);
		}
	}
	
}
