package com.example.demo.controller;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Service.TeacherService;
import com.example.demo.model.Teacher;
import com.example.demo.repositories.TeacherRepository;



@RestController
@RequestMapping("/teach")
public class TeacherController {
	@Autowired
	TeacherRepository teacherRepository;
	
	@Autowired
	TeacherService teacherService;
	
	
	
	@PostMapping("/create")
	public Teacher create(@RequestBody Teacher newTeacherObject) {
		newTeacherObject.setId(teacherService.generateSequence(Teacher.SEQUENCE_NAME));
		return teacherRepository.save(newTeacherObject);
	}
	
	@GetMapping("/read")
	public List<Teacher> read(){
		return teacherRepository.findAll();
	}
	
	@GetMapping("/read/{id}")
	public Teacher read(@PathVariable Long id) {
		Optional<Teacher> teaObj = teacherRepository.findById(id);
		if(teaObj.isPresent()) {
			return teaObj.get();
		}else {
			throw new RuntimeException("teacher not found with id "+id);
		}
	}
	
	@PutMapping("/update")
	public Teacher update(@RequestBody Teacher teacherObject) {
		return teacherRepository.save(teacherObject);
	}
	
	@DeleteMapping("/delete/{id}")
	public String delete(@PathVariable Long id) {
//		Optional<Student> studentObj = studentRepository.findById(id);
//		if(studentObj.isPresent()) {
//			studentRepository.delete(studentObj.get());
//			return "student deleted with id "+id;
//		}else {
//			throw new RuntimeException("student not found for id "+id);
//		}
		
	boolean teacherexists=teacherRepository.existsById(id);
	if(teacherexists)
	{
		teacherRepository.deleteById(id);
		return "teacher with id "+id;
	}
	return "teacher doesn't exists with id";
	}
	
}


