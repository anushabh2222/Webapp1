import { React, Component } from 'react';
import './App.css';

class Home extends Component {

    render(){
        return(
            <h1>Web application</h1>   
        );
  }
}
    export default Home;

