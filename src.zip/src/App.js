import React  from 'react';

import './App.css';
import  Student from './Student';
import  Home from './Home';
import {Route,Link} from "react-router-dom";
import NavBar from './NavBar';



function App() {
  return (
    <div className="App">
      <NavBar/>
      <Route exact path="/" component={Home}/> 
      <Route  exact path="/student" component={Student}/> 

    </div>
  );
}

export default App;
