import { React, Component } from 'react';
import './App.css';

class Student extends Component {
  constructor(){
    super();
    this.state = {
      // title : " web Application",
      act : 0,
      idx : '',
      datas : []
    }
  }

  componentDidMount(){
    this.refs.txtName.focus();
  }

  handleSubmit=(e)=>{
    e.preventDefault();
    let datas = this.state.datas;
    let name = this.refs.txtName.value;
    let specification = this.refs.txtSpecification.value;
    let dob = this.refs.txtDob.value;
    let createddate = this.refs.txtCreateddate.value;

    if(this.state.act === 0)
    {
      let data = {
        "name" : name,
        "specification" : specification,
        "dob":dob,
        "createddate":createddate
      }
      datas.push(data);
    }
    else
    {
        let index = this.state.idx;
        datas[index].name = name;
        datas[index].specification = specification;    
        datas[index].dob = dob;
        datas[index].createddate = createddate;         
    }
    
    
    this.setState({
      datas : datas,
      act : 0
    })
    this.refs.myForm.reset();
    this.refs.txtName.focus();
  }

  handleDelete = (index) =>{
    let datas = this.state.datas;
    datas.splice(index,1);
    this.setState({
      datas:datas
    })
    this.refs.txtName.focus();
  }

  handleEdit = (index) => {
    let data = this.state.datas[index];
    this.refs.txtName.value = data.name;
    this.refs.txtSpecification.value = data.specification;
    this.refs.txtDob.value = data.dob;
    this.refs.txtCreateddate.value = data.createddate;
    

    this.setState({
      act: 1,
      idx : index
    })
    
  }
  
  render() { 
    let datas = this.state.datas;
    return ( 
      <div className="App">
      
        <form ref="myForm" className="myForm">
        <h1>{this.state.title}</h1>
        <h2>student registration</h2>
          <label>Name</label>
          <input type="text" ref="txtName" placeholder="Enter name" className="formField"/>
          <label>Specification</label>
          <input type="text" ref="txtSpecification" placeholder="Enter specification"  className="formField"/>
          <label>Dob</label>
          <input type="text" ref="txtDob" placeholder="Enter dob" className="formField"/>
          <label>Created date</label>
          <input type="text" ref="txtCreateddate" placeholder="Enter created date" className="formField"/>
          
          <button onClick={e => this.handleSubmit(e)} className="myButton"> Save</button>
        </form>
        <pre className="listView">
          {datas.map((data,index)=>
            <li key={index}>  
            {index+1}, {data.name} ,{data.specification},{data.dob},{data.createddate}  
            <button onClick={e => this.handleDelete(index)} className="myListButton">Delete</button>
            <button onClick={e => this.handleEdit (index)} className="myListButton">Edit</button>
            </li>
            )
          }
        </pre>
      </div>
     );
  }
}
 
export default Student;